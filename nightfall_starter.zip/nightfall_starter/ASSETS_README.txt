
Nightfall Survivors — Asset wiring (auto-prepared)
=================================================

This folder contains normalized asset names expected by the game:

- assets/player.png                (from vampire pack, if found; else placeholder)
- assets/enemies/grunt.png         (from swordsman pack, if found; else placeholder)
- assets/enemies/boss.png          (from vampire/swordsman pack, if found; else placeholder)
- assets/ui/gem.png                (XP gem; placeholder if not found)
- assets/bg/tile.png               (from undead tileset; placeholder if not found)

Original source zips (uploaded by user) were extracted under:
- /mnt/data/extracted_assets

You can replace any PNG in assets/ with your preferred sprite.
No code changes required.
