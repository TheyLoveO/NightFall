// Nightfall Survivors (Sprite-ready Starter)
// Run: go mod init nightfall && go get github.com/hajimehoshi/ebiten/v2 && go run .
package main

import (
    "fmt"
    "image/color"
    "image/png"
    "log"
    "math"
    "math/rand"
    "os"
    "time"

    "github.com/hajimehoshi/ebiten/v2"
)

const (
    screenW = 960
    screenH = 540
)

type GameState int

const (
    StateMenu GameState = iota
    StateCharacterSelect
    StateSettings
    StatePlaying
    StateLevelUp
    StateGameOver
)

// --- simplified character & entities (same as earlier example, trimmed) ---
type CharacterID int
const (
    CharHunter CharacterID = iota
    CharAlchemist
    CharPaladin
    CharNecromancer
    CharCyberVampire
)
type Character struct {
    ID CharacterID; Name string; BaseHP, MoveSpeed, WeaponDamage, AttackCooldown float64; ProjectileCount int
}
var Characters = []Character{
    {CharHunter, "The Hunter", 100, 2.8, 12, 0.9, 1},
    {CharAlchemist, "The Alchemist", 90, 2.6, 10, 1.2, 1},
    {CharPaladin, "The Paladin", 120, 2.4, 8, 0.7, 2},
    {CharNecromancer, "The Necromancer", 85, 2.7, 9, 1.3, 1},
    {CharCyberVampire, "The Cyber Vampire", 95, 2.9, 7, 1.0, 1},
}

type Vec2 struct{ X, Y float64 }
func (v Vec2) Add(u Vec2) Vec2 { return Vec2{v.X + u.X, v.Y + u.Y} }
func (v Vec2) Sub(u Vec2) Vec2 { return Vec2{v.X - u.X, v.Y - u.Y} }
func (v Vec2) Mul(s float64) Vec2 { return Vec2{v.X * s, v.Y * s} }
func (v Vec2) Len() float64 { return math.Hypot(v.X, v.Y) }
func (v Vec2) Norm() Vec2 { l := v.Len(); if l == 0 { return Vec2{} }; return Vec2{v.X/l, v.Y/l} }

type Player struct {
    Pos Vec2; HP, MaxHP, MoveSpeed, WeaponDamage float64
    CooldownTarget float64; cooldown float64
    ProjectileCount int; Level, Exp, NextLevelXP int
    Char CharacterID
}

type Enemy struct{ Pos Vec2; HP, Speed float64; Alive bool; Radius float64; Boss bool; Contact float64 }
type Projectile struct{ Pos, Vel Vec2; Damage float64; Alive bool; Pierce int; Radius float64; TTL float64; Kind int }
type Gem struct{ Pos Vec2; Alive bool; Value int }

type Button struct{ Rect [4]float64; Label string; Hover bool; Action func() }

// --- Assets ---
type Assets struct {
    Player *ebiten.Image
    Enemy  *ebiten.Image
    Boss   *ebiten.Image
    Gem    *ebiten.Image
    BGTile *ebiten.Image
    // add more as needed
}
func loadOptionalPNG(path string) *ebiten.Image {
    f, err := os.Open(path); if err != nil { return nil }
    defer f.Close()
    img, err := png.Decode(f); if err != nil { return nil }
    return ebiten.NewImageFromImage(img)
}

// --- Game ---
type Game struct {
    state GameState
    rng *rand.Rand
    buttons, charButtons []Button

    assets Assets

    player Player
    enemies []Enemy
    projectiles []Projectile
    gems []Gem

    timeSurvived, spawnRate, bossTimer float64
    score int
}

func NewGame() *Game {
    g := &Game{
        state: StateMenu,
        rng: rand.New(rand.NewSource(time.Now().UnixNano())),
        spawnRate: 1.2, bossTimer: 120,
    }
    g.assets = Assets{
        Player: loadOptionalPNG("assets/player.png"),
        Enemy:  loadOptionalPNG("assets/enemies/grunt.png"),
        Boss:   loadOptionalPNG("assets/enemies/boss.png"),
        Gem:    loadOptionalPNG("assets/ui/gem.png"),
        BGTile: loadOptionalPNG("assets/bg/tile.png"),
    }
    g.setupMenu()
    return g
}

func (g *Game) setupMenu() {
    g.buttons = []Button{
        g.makeButton(380, 260, 200, 40, "Start Game", func(){ g.state = StateCharacterSelect; g.setupCharacterSelect() }),
        g.makeButton(380, 310, 200, 40, "Character Select", func(){ g.state = StateCharacterSelect; g.setupCharacterSelect() }),
        g.makeButton(380, 360, 200, 40, "Settings", func(){ g.state = StateSettings }),
        g.makeButton(380, 410, 200, 40, "Quit", func(){ ebiten.Exit() }),
    }
}
func (g *Game) setupCharacterSelect() {
    g.charButtons = nil
    x, y := 180.0, 160.0
    for i, c := range Characters {
        i := i
        g.charButtons = append(g.charButtons, g.makeButton(x, y, 300, 48, c.Name, func(){ g.startRun(Characters[i]) }))
        y += 60
    }
}

func (g *Game) startRun(ch Character) {
    g.enemies, g.projectiles, g.gems = nil, nil, nil
    g.timeSurvived, g.spawnRate, g.bossTimer, g.score = 0, 1.2, 110+g.rng.Float64()*40, 0

    g.player = Player{
        Pos: Vec2{screenW/2, screenH/2},
        HP: ch.BaseHP, MaxHP: ch.BaseHP, MoveSpeed: ch.MoveSpeed, WeaponDamage: ch.WeaponDamage,
        CooldownTarget: ch.AttackCooldown, ProjectileCount: ch.ProjectileCount,
        Level: 1, Exp: 0, NextLevelXP: 10, Char: ch.ID,
    }
    g.state = StatePlaying
}

func (g *Game) makeButton(x,y,w,h float64, label string, action func()) Button {
    return Button{Rect: [4]float64{x,y,w,h}, Label: label, Action: action}
}

func (g *Game) Update() error {
    switch g.state {
    case StateMenu:
        g.updateButtons(g.buttons)
    case StateCharacterSelect:
        g.updateButtons(g.charButtons)
    case StatePlaying:
        g.updatePlaying()
    case StateGameOver:
        // press enter to return to menu
        if ebiten.IsKeyPressed(ebiten.KeyEnter) { g.state = StateMenu; g.setupMenu() }
    }
    return nil
}
func (g *Game) updateButtons(btns []Button) {
    x,y := ebiten.CursorPosition()
    mx, my := float64(x), float64(y)
    for i := range btns {
        b := &btns[i]; X,Y,W,H := b.Rect[0], b.Rect[1], b.Rect[2], b.Rect[3]
        b.Hover = (mx>=X && mx<=X+W && my>=Y && my<=Y+H)
    }
    if ebiten.IsMouseButtonPressed(ebiten.MouseButtonLeft) {
        for i := range btns { if btns[i].Hover && btns[i].Action != nil { btns[i].Action(); break } }
    }
    switch g.state {
    case StateMenu: g.buttons = btns
    case StateCharacterSelect: g.charButtons = btns
    }
}

func (g *Game) updatePlaying() {
    dt := 1.0/60.0
    g.timeSurvived += dt
    if g.timeSurvived > 60 { g.spawnRate = 1.6 }
    if g.timeSurvived > 120 { g.spawnRate = 2.2 }
    // movement
    mv := Vec2{}
    if ebiten.IsKeyPressed(ebiten.KeyW) || ebiten.IsKeyPressed(ebiten.KeyUp) { mv.Y -= 1 }
    if ebiten.IsKeyPressed(ebiten.KeyS) || ebiten.IsKeyPressed(ebiten.KeyDown) { mv.Y += 1 }
    if ebiten.IsKeyPressed(ebiten.KeyA) || ebiten.IsKeyPressed(ebiten.KeyLeft) { mv.X -= 1 }
    if ebiten.IsKeyPressed(ebiten.KeyD) || ebiten.IsKeyPressed(ebiten.KeyRight) { mv.X += 1 }
    if mv.Len() > 0 {
        g.player.Pos = g.player.Pos.Add(mv.Norm().Mul(g.player.MoveSpeed*120*dt))
    }
    // attack cooldown & fire
    g.player.cooldown -= dt
    if g.player.cooldown <= 0 {
        g.fireWeapon()
        g.player.cooldown = g.player.CooldownTarget
    }
    // spawn enemies probabilistically
    spawns := g.spawnRate * dt
    for spawns > 0 {
        if g.rng.Float64() < spawns { g.spawnEnemy(false) }
        spawns -= 1
    }
    g.bossTimer -= dt
    if g.bossTimer <= 0 { g.spawnEnemy(true); g.bossTimer = 120 + g.rng.Float64()*60 }
    // update enemies
    for i := range g.enemies {
        if !g.enemies[i].Alive { continue }
        dir := g.player.Pos.Sub(g.enemies[i].Pos).Norm()
        g.enemies[i].Pos = g.enemies[i].Pos.Add(dir.Mul(g.enemies[i].Speed*60*dt))
        if g.dist(g.enemies[i].Pos, g.player.Pos) < (g.enemies[i].Radius + 10) {
            g.player.HP -= g.enemies[i].Contact
            if g.player.HP <= 0 { g.state = StateGameOver }
        }
    }
    // update projectiles
    for i := range g.projectiles {
        if !g.projectiles[i].Alive { continue }
        g.projectiles[i].TTL -= dt
        if g.projectiles[i].TTL <= 0 { g.projectiles[i].Alive = false; continue }
        g.projectiles[i].Pos = g.projectiles[i].Pos.Add(g.projectiles[i].Vel.Mul(60*dt))
        for ei := range g.enemies {
            if !g.enemies[ei].Alive { continue }
            if g.dist(g.projectiles[i].Pos, g.enemies[ei].Pos) < (g.projectiles[i].Radius + g.enemies[ei].Radius) {
                g.enemies[ei].HP -= g.projectiles[i].Damage
                if g.projectiles[i].Pierce > 0 { g.projectiles[i].Pierce-- } else { g.projectiles[i].Alive = false }
                if g.enemies[ei].HP <= 0 { g.killEnemy(ei) }
                break
            }
        }
    }
    // collect gems
    for gi := range g.gems {
        if !g.gems[gi].Alive { continue }
        if g.dist(g.gems[gi].Pos, g.player.Pos) < 18 { g.collectGem(gi) }
    }
    // level-up check simplified
    for g.player.Exp >= g.player.NextLevelXP {
        g.player.Exp -= g.player.NextLevelXP
        g.player.Level++
        g.player.NextLevelXP = int(float64(g.player.NextLevelXP)*1.35)+5
        // pick a simple upgrade automatically for this minimal file
        g.player.WeaponDamage *= 1.2
    }
}

func (g *Game) fireWeapon() {
    // nearest enemy
    var target *Enemy; minD := 1e9
    for i := range g.enemies {
        if !g.enemies[i].Alive { continue }
        d := g.dist(g.enemies[i].Pos, g.player.Pos)
        if d < minD { minD = d; target = &g.enemies[i] }
    }
    dmg := g.player.WeaponDamage
    dir := Vec2{1,0}; if target != nil { dir = target.Pos.Sub(g.player.Pos).Norm() }
    g.projectiles = append(g.projectiles, Projectile{
        Pos: g.player.Pos, Vel: dir.Mul(6.0), Damage: dmg, Alive: true, Pierce: 1, Radius: 6, TTL: 2.0, Kind: 0,
    })
}

func (g *Game) spawnEnemy(boss bool) {
    side := g.rng.Intn(4); margin := 40.0; var pos Vec2
    switch side {
    case 0: pos = Vec2{-margin, g.rng.Float64()*screenH}
    case 1: pos = Vec2{screenW+margin, g.rng.Float64()*screenH}
    case 2: pos = Vec2{g.rng.Float64()*screenW, -margin}
    case 3: pos = Vec2{g.rng.Float64()*screenW, screenH+margin}
    }
    hp := 20.0 + g.timeSurvived*0.6; speed := 0.8 + g.rng.Float64()*0.5 + g.timeSurvived*0.002; radius := 10.0; contact := 4.0
    if boss { hp = 400 + g.timeSurvived*8; speed = 1.1; radius = 24; contact = 15 }
    g.enemies = append(g.enemies, Enemy{Pos: pos, HP: hp, Speed: speed, Alive: true, Radius: radius, Boss: boss, Contact: contact})
}
func (g *Game) killEnemy(i int) {
    if !g.enemies[i].Alive { return }
    g.enemies[i].Alive = false
    val := 1; if g.enemies[i].Boss { val = 5 }
    g.gems = append(g.gems, Gem{Pos: g.enemies[i].Pos, Alive: true, Value: val})
    g.score += 5; if g.enemies[i].Boss { g.score += 100 }
}
func (g *Game) collectGem(i int) {
    if !g.gems[i].Alive { return }
    g.gems[i].Alive = false
    g.player.Exp += g.gems[i].Value
}

func (g *Game) Draw(screen *ebiten.Image) {
    // bg tile
    if g.assets.BGTile != nil {
        tw, th := g.assets.BGTile.Size()
        for y := 0; y < screenH; y += th {
            for x := 0; x < screenW; x += tw {
                op := &ebiten.DrawImageOptions{}
                op.GeoM.Translate(float64(x), float64(y))
                screen.DrawImage(g.assets.BGTile, op)
            }
        }
    } else {
        screen.Fill(color.RGBA{8, 10, 18, 255})
    }

    switch g.state {
    case StateMenu:
        drawText(screen, 320, 120, "Nightfall Survivors", color.White)
        g.drawButtons(screen, g.buttons)
    case StateCharacterSelect:
        drawText(screen, 360, 80, "Choose Your Hunter", color.White)
        g.drawButtons(screen, g.charButtons)
    case StatePlaying, StateLevelUp, StateGameOver:
        // gems
        for _, ge := range g.gems {
            if !ge.Alive { continue }
            if g.assets.Gem != nil {
                op := &ebiten.DrawImageOptions{}; w,h := g.assets.Gem.Size()
                op.GeoM.Translate(-float64(w)/2, -float64(h)/2); op.GeoM.Translate(ge.Pos.X, ge.Pos.Y)
                screen.DrawImage(g.assets.Gem, op)
            } else {
                fillCircle(screen, ge.Pos, 4, color.RGBA{100,200,255,255})
            }
        }
        // enemies
        for _, e := range g.enemies {
            if !e.Alive { continue }
            img := g.assets.Enemy; if e.Boss && g.assets.Boss != nil { img = g.assets.Boss }
            if img != nil {
                op := &ebiten.DrawImageOptions{}; w,h := img.Size()
                op.GeoM.Translate(-float64(w)/2, -float64(h)/2); op.GeoM.Translate(e.Pos.X, e.Pos.Y)
                screen.DrawImage(img, op)
            } else {
                col := color.RGBA{160,60,60,255}
                if e.Boss { col = color.RGBA{200,80,200,255} }
                fillCircle(screen, e.Pos, e.Radius, col)
            }
        }
        // projectiles (simple circles)
        for _, p := range g.projectiles {
            if !p.Alive { continue }
            fillCircle(screen, p.Pos, p.Radius, color.RGBA{230,230,230,255})
        }
        // player
        if g.assets.Player != nil {
            op := &ebiten.DrawImageOptions{}; w,h := g.assets.Player.Size()
            op.GeoM.Translate(-float64(w)/2, -float64(h)/2); op.GeoM.Translate(g.player.Pos.X, g.player.Pos.Y)
            screen.DrawImage(g.assets.Player, op)
        } else {
            fillCircle(screen, g.player.Pos, 10, color.RGBA{200,240,255,255})
        }
        // UI
        drawText(screen, screenW-220, 20, fmt.Sprintf("Time: %02d:%02d", int(g.timeSurvived)/60, int(g.timeSurvived)%60), color.White)
        drawText(screen, screenW-220, 40, fmt.Sprintf("Score: %d", g.score), color.White)
        if g.state == StateGameOver {
            drawText(screen, 420, 200, "Game Over", color.White)
        }
    }
}

func (g *Game) drawButtons(screen *ebiten.Image, btns []Button) {
    for _, b := range btns {
        bg := color.RGBA{40,44,60,255}; if b.Hover { bg = color.RGBA{60,66,90,255} }
        fillRect(screen, b.Rect[0], b.Rect[1], b.Rect[2], b.Rect[3], bg)
        drawText(screen, b.Rect[0]+12, b.Rect[1]+14, b.Label, color.White)
    }
}

func (g *Game) Layout(ow,oh int) (int,int) { return screenW, screenH }

// --- drawing utils ---
func drawText(dst *ebiten.Image, x,y float64, s string, col color.Color) {
    // Placeholder: tiny blocks as "text". Replace with a font for real UI.
    fillRect(dst, x-2, y-2, float64(len(s)*6+4), 12, color.RGBA{0,0,0,60})
    for i := 0; i < len(s); i++ { fillRect(dst, x+float64(i*6), y, 4, 1, color.White) }
}
func fillRect(dst *ebiten.Image, x,y,w,h float64, c color.Color) {
    img := ebiten.NewImage(int(w), int(h)); img.Fill(c)
    op := &ebiten.DrawImageOptions{}; op.GeoM.Translate(x,y); dst.DrawImage(img, op)
}
func fillCircle(dst *ebiten.Image, center Vec2, r float64, c color.Color) {
    step := int(math.Max(1, r/2))
    for a := 0; a < 360; a += step {
        rad := float64(a) * math.Pi / 180
        fx := center.X + math.Cos(rad)*r; fy := center.Y + math.Sin(rad)*r
        fillRect(dst, fx-1, fy-1, 2, 2, c)
    }
}
func (g *Game) dist(a,b Vec2) float64 { return a.Sub(b).Len() }

func main() {
    ebiten.SetWindowSize(screenW, screenH)
    ebiten.SetWindowTitle("Nightfall Survivors — Sprite-ready Starter")
    game := NewGame()
    if err := ebiten.RunGame(game); err != nil { log.Fatal(err) }
}
